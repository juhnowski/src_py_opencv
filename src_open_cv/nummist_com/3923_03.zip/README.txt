Scripts are in the "cameo" folder.

The managers.py script is unchanged since Chapter 2.